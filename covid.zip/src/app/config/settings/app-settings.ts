export class AppSettings {

	public static SERVER_DEV = 'http://localhost:8100/';

	// API
	public static PANDEMIC_API = 'assets/mock/pandamic.json';

}
